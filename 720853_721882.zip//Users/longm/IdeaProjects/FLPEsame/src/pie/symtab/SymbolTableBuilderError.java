package pie.symtab;

public class SymbolTableBuilderError extends RuntimeException {

  public SymbolTableBuilderError() {
    super();
  }

  public SymbolTableBuilderError(String message) {
    super(message);
  }

}
